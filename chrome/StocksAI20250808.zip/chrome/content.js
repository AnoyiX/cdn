const mainfest = chrome.runtime.getManifest()
console.log(`%c${mainfest.name} ${mainfest.version}`, 'color:Green')

document.addEventListener('Stocks-AI-Extension', (event) => {
    chrome.runtime.sendMessage(event.detail, (response) => {
        if (response && Object.keys(event.detail).includes('func')) {
            document.dispatchEvent(new CustomEvent("Stocks-AI-Extension-Response", {
                detail: {
                    func: event.detail.func,
                    response
                }
            }))
        }
    })
})

document.addEventListener('Stocks-AI-Extension-Status', (event) => {
    // document.getElementById("ExtensionInit").click()
    console.log("Stocks-AI-Extension-Status", event)
    document.dispatchEvent(new CustomEvent("Stocks-AI-Extension-Status-Response", {
        detail: {
            connected: true,
            mainfest
        }
    }))
})