// Remote message handler
const COMMAND = {
    stockPosition: (args, sendResponse) => {
        const referrer = "https://tzzb.10jqka.com.cn/pc/index.html"
        const contentType = "application/x-www-form-urlencoded"
        chrome.cookies.get({ name: 'userid', url: 'https://tzzb.10jqka.com.cn' }, cookie => {
            if (!cookie) {
                sendResponse({ error_code: '1', error_msg: '【投资账本】未登录' })
                return
            }
            const userid = cookie.value
            fetch("https://tzzb.10jqka.com.cn/caishen_httpserver/tzzb/caishen_fund/pc/account/v1/account_list", {
                method: 'POST',
                headers: {
                    "content-type": contentType
                },
                referrer,
                body: `terminal=1&version=0.0.0&userid=${userid}&user_id=${userid}`,
            }).then(response => response.json()).then(data => {
                if (data.error_code === "0" && data.ex_data.common.length > 0) {
                    const fund_key = data.ex_data.common[0].fund_key
                    fetch("https://tzzb.10jqka.com.cn/caishen_httpserver/tzzb/caishen_fund/pc/asset/v1/stock_position", {
                        method: "POST",
                        headers: {
                            "content-type": contentType
                        },
                        referrer,
                        body: `terminal=1&version=0.0.0&userid=${userid}&user_id=${userid}&manual_id=&fund_key=${fund_key}&rzrq_fund_key=`,
                    }).then(response => response.json()).then(data => {
                        sendResponse(data)
                    }).catch(error => {
                        sendResponse({ error_code: '2', error_msg: `获取持仓列表失败：${error}` })
                    })
                } else {
                    sendResponse(data)
                }
            }).catch(error => {
                sendResponse({ error_code: '2', error_msg: `获取股票账户列表失败：${error}` })
            })
        })
    },
    watchlist: (args, sendResponse) => {
        const referrer = "https://t.10jqka.com.cn/newcircle/user/userPersonal/"
        fetch("https://t.10jqka.com.cn/newcircle/group/getSelfStockWithMarket/", {
            method: 'GET',
            referrer,
        }).then(response => response.json()).then(data => {
            sendResponse(data)
        }).catch(error => {
            sendResponse({ error_code: '2', error_msg: `获取我的自选列表失败：${error}` })
        })
    },
    modifySelfStock: (args, sendResponse) => {
        const { op, stockcode } = args
        const referrer = "https://t.10jqka.com.cn/newcircle/user/userPersonal/"
        fetch(`https://t.10jqka.com.cn/newcircle/group/modifySelfStock/?op=${op}&stockcode=${stockcode}`, {
            method: 'GET',
            referrer
        }).then(response => response.json()).then(data => {
            sendResponse(data)
        }).catch(error => {
            sendResponse({ error_code: '2', error_msg: `删除自选股票失败：${error}` })
        })
    },
    timeShare: (args, sendResponse) => {
        const referrer = "https://tzzb.10jqka.com.cn/pc/index.html"
        const contentType = "application/x-www-form-urlencoded"
        chrome.cookies.get({ name: 'userid', url: 'https://tzzb.10jqka.com.cn' }, cookie => {
            if (!cookie) {
                sendResponse({ error_code: '1', error_msg: '【投资账本】未登录' })
                return
            }
            const userid = cookie.value
            fetch("https://tzzb.10jqka.com.cn/caishen_httpserver/tzzb/caishen_fund/pc/account/v1/account_list", {
                method: 'POST',
                headers: {
                    "content-type": contentType
                },
                referrer,
                body: `terminal=1&version=0.0.0&userid=${userid}&user_id=${userid}`,
            }).then(response => response.json()).then(data => {
                if (data.error_code === "0" && data.ex_data.common.length > 0) {
                    const fund_key = data.ex_data.common[0].fund_key
                    fetch("https://tzzb.10jqka.com.cn/caishen_httpserver/tzzb/caishen_fund/pc/asset/v1/time_share", {
                        method: "POST",
                        headers: {
                            "content-type": contentType
                        },
                        referrer,
                        body: `terminal=1&version=0.0.0&userid=${userid}&user_id=${userid}&manual_id=&fundid=&fund_key=${fund_key}&rzrq_fund_key=`,
                    }).then(response => response.json()).then(data => {
                        sendResponse(data)
                    }).catch(error => {
                        sendResponse({ error_code: '2', error_msg: `获取当日盈亏失败：${error}` })
                    })
                } else {
                    sendResponse(data)
                }
            }).catch(error => {
                sendResponse({ error_code: '2', error_msg: `获取股票账户列表失败：${error}` })
            })
        })
    }
}

// Handle Message
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (Object.keys(msg).includes('func') && Object.keys(COMMAND).includes(msg['func'])) {
        COMMAND[msg['func']](msg['args'], sendResponse)
    }
    return true
})
