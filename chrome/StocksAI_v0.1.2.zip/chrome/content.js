const mainfest = chrome.runtime.getManifest()
console.log(`%c${mainfest.name} ${mainfest.version}`, 'color:Green')

// 检查扩展上下文是否有效
function isExtensionContextValid() {
    return chrome.runtime && chrome.runtime.id
}

// 安全的消息发送函数
function safeSendMessage(message, callback) {
    if (!isExtensionContextValid()) {
        console.warn('Extension context invalidated, skipping message')
        return
    }
    
    try {
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                console.warn('Runtime error:', chrome.runtime.lastError.message)
                return
            }
            callback && callback(response)
        })
    } catch (error) {
        console.warn('Failed to send message:', error)
    }
}

document.addEventListener('Stocks-AI-Extension', (event) => {
    safeSendMessage(event.detail, (response) => {
        if (response && Object.keys(event.detail).includes('func')) {
            document.dispatchEvent(new CustomEvent("Stocks-AI-Extension-Response", {
                detail: {
                    func: event.detail.func,
                    response
                }
            }))
        }
    })
})

document.addEventListener('Stocks-AI-Extension-Status', (event) => {
    document.dispatchEvent(new CustomEvent("Stocks-AI-Extension-Status-Response", {
        detail: {
            connected: isExtensionContextValid(),
            mainfest: isExtensionContextValid() ? mainfest : null
        }
    }))
})
